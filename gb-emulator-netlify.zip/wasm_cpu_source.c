// wasm_cpu_source.c - optional CPU core skeleton
#include <stdint.h>
#include <stdlib.h>

uint8_t memory[0x10000];
void cpu_init(){}
void cpu_step_frame(){}
